<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

if (current_user()) {
    audit('LOGOUT', 'user', current_user_id(), 'User logged out.');
}

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'], $params['secure'], $params['httponly']
    );
}
session_destroy();

header('Location: ' . BASE_URL . '/auth/login.php');
exit;
