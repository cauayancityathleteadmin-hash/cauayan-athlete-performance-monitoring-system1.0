<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_coach_or_admin();

if (is_admin()) redirect('admin/athletes.php');

$q=trim($_GET['q']??'');
$coachId=get_coach_id_for_user(current_user_id());
$params=[];
$sql="SELECT a.id,a.athlete_code,a.birthdate,a.status,a.coach_id,
      CONCAT_WS(' ',a.first_name,a.middle_name,a.last_name) AS athlete_name,
      s.sport_name,e.event_name,sc.school_name,c.coach_code
      FROM athletes a
      JOIN sports s ON s.id=a.sport_id
      JOIN events e ON e.id=a.event_id
      LEFT JOIN schools sc ON sc.id=a.school_id
      JOIN coaches c ON c.id=a.coach_id
      WHERE 1=1";
if($q!==''){ $sql.=" AND (a.athlete_code LIKE ? OR a.first_name LIKE ? OR a.last_name LIKE ?)"; $like="%{$q}%"; array_push($params,$like,$like,$like); }
$sql.=" ORDER BY a.last_name,a.first_name";
$stmt=db()->prepare($sql);$stmt->execute($params);$athletes=$stmt->fetchAll();

$pageTitle='All Athletes';
require __DIR__.'/../includes/header.php';
?>
<div class="page-title"><h1>All Athletes</h1><div class="actions"><a class="btn" href="<?= BASE_URL ?>/admin/athletes.php?add=1">Add Athlete</a></div></div>
<div class="panel">
<p class="small">You can view all athletes, but you can only manage athletes assigned to you.</p>
<form class="search-bar" method="get"><input name="q" value="<?= e($q) ?>" placeholder="Search athlete ID or name"><button class="btn" type="submit">Search</button></form>
<table>
<thead><tr><th>ID</th><th>Athlete</th><th>Sport / Event</th><th>School</th><th>Coach</th><th>Status</th></tr></thead>
<tbody>
<?php foreach($athletes as $a): ?>
<tr>
<td><a href="<?= BASE_URL ?>/athletes/view.php?id=<?= (int)$a['id'] ?>"><?= e($a['athlete_code']) ?></a></td>
<td><?= e($a['athlete_name']) ?><br><span class="small">Age <?= calculate_age($a['birthdate']) ?></span></td>
<td><?= e($a['sport_name']) ?><br><span class="small"><?= e($a['event_name']) ?></span></td>
<td><?= e($a['school_name']??'—') ?></td>
<td><?= e($a['coach_code']) ?></td>
<td><span class="badge <?= e($a['status']) ?>"><?= e(ucfirst($a['status'])) ?></span></td>
</tr>
<?php endforeach; ?>
</tbody></table>
</div>
<?php require __DIR__.'/../includes/footer.php'; ?>
