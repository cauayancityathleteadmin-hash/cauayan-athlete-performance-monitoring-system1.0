<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_coach_or_admin();

if (is_admin()) {
    http_response_code(403);
    exit('Reports are available to coaches for their assigned athletes only.');
}

$coachId = get_coach_id_for_user(current_user_id());
if (!$coachId) {
    http_response_code(403);
    exit('No coach profile is linked to this account.');
}

$athletesStmt = db()->prepare(
    "SELECT a.id, a.athlete_code,
            CONCAT_WS(' ', a.first_name, a.middle_name, a.last_name, a.suffix) AS athlete_name
     FROM athletes a
     WHERE a.coach_id = ?
     ORDER BY a.last_name, a.first_name"
);
$athletesStmt->execute([$coachId]);
$athletes = $athletesStmt->fetchAll();

$athleteId = (int)($_GET['athlete_id'] ?? 0);
$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo = trim($_GET['date_to'] ?? '');
$athlete = null;
$assessments = [];

$dateFromObject = $dateFrom === '' ? null : DateTime::createFromFormat('!Y-m-d', $dateFrom);
$dateToObject = $dateTo === '' ? null : DateTime::createFromFormat('!Y-m-d', $dateTo);
$validDateFrom = $dateFromObject === null || ($dateFromObject !== false && $dateFromObject->format('Y-m-d') === $dateFrom);
$validDateTo = $dateToObject === null || ($dateToObject !== false && $dateToObject->format('Y-m-d') === $dateTo);
if (!$validDateFrom || !$validDateTo || ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo)) {
    $dateFrom = '';
    $dateTo = '';
}

if ($athleteId) {
    $athleteStmt = db()->prepare(
        "SELECT a.id, a.athlete_code, a.birthdate, a.gender, a.status,
                CONCAT_WS(' ', a.first_name, a.middle_name, a.last_name, a.suffix) AS athlete_name,
                s.sport_name, e.event_name, sc.school_name,
                CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name, c.suffix) AS coach_name
         FROM athletes a
         JOIN sports s ON s.id = a.sport_id
         JOIN events e ON e.id = a.event_id
         LEFT JOIN schools sc ON sc.id = a.school_id
         JOIN coaches c ON c.id = a.coach_id
         WHERE a.id = ? AND a.coach_id = ?"
    );
    $athleteStmt->execute([$athleteId, $coachId]);
    $athlete = $athleteStmt->fetch() ?: null;

    if ($athlete) {
        $params = [$athleteId];
        $dateWhere = '';
        if ($dateFrom !== '') {
            $dateWhere .= ' AND ass.assessment_date >= ?';
            $params[] = $dateFrom;
        }
        if ($dateTo !== '') {
            $dateWhere .= ' AND ass.assessment_date <= ?';
            $params[] = $dateTo;
        }

        $assessmentStmt = db()->prepare(
            "SELECT ass.id, ass.assessment_date, ass.assessment_type, ass.remarks,
                    pm.metric_name, pm.unit, pm.data_type, pm.decimal_places,
                    ar.value_decimal, ar.value_text, ar.notes
             FROM assessments ass
             LEFT JOIN assessment_results ar ON ar.assessment_id = ass.id
             LEFT JOIN performance_metrics pm ON pm.id = ar.metric_id
             WHERE ass.athlete_id = ?{$dateWhere}
             ORDER BY ass.assessment_date DESC, ass.id DESC, pm.metric_name"
        );
        $assessmentStmt->execute($params);
        foreach ($assessmentStmt->fetchAll() as $row) {
            $assessments[$row['id']]['date'] = $row['assessment_date'];
            $assessments[$row['id']]['type'] = $row['assessment_type'];
            $assessments[$row['id']]['remarks'] = $row['remarks'];
            if ($row['metric_name'] !== null) {
                $value = $row['data_type'] === 'text'
                    ? $row['value_text']
                    : number_format((float)$row['value_decimal'], (int)$row['decimal_places']);
                $assessments[$row['id']]['results'][] = [
                    'metric' => $row['metric_name'],
                    'unit' => $row['unit'],
                    'value' => $value,
                    'notes' => $row['notes'],
                ];
            }
        }
    }
}

$pageTitle = 'Athlete Reports';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-title">
<h1>Athlete Performance Report</h1>
<div class="actions"><button class="btn" type="button" onclick="window.print()">Print Report</button></div>
</div>

<div class="panel report-controls">
<h2>Choose Athlete</h2>
<form class="search-bar" method="get">
<select name="athlete_id" required>
<option value="">Select an assigned athlete</option>
<?php foreach ($athletes as $item): ?>
<option value="<?= (int)$item['id'] ?>" <?= $athleteId === (int)$item['id'] ? 'selected' : '' ?>><?= e($item['athlete_code'] . ' — ' . $item['athlete_name']) ?></option>
<?php endforeach; ?>
</select>
<label class="small" for="date_from">From</label><input id="date_from" type="date" name="date_from" value="<?= e($dateFrom) ?>">
<label class="small" for="date_to">To</label><input id="date_to" type="date" name="date_to" value="<?= e($dateTo) ?>">
<button class="btn" type="submit">Generate</button>
</form>
<p class="small">Only athletes currently assigned to your coach profile can be selected.</p>
</div>

<?php if ($athlete): ?>
<div class="panel report-sheet">
<div class="report-heading">
<div><h2><?= e($athlete['athlete_name']) ?></h2><p class="small">Athlete ID: <?= e($athlete['athlete_code']) ?> · Coach: <?= e($athlete['coach_name']) ?></p></div>
<div class="small">Generated <?= e(date('Y-m-d H:i')) ?></div>
</div>
<div class="report-summary">
<div><strong>Sport</strong><span><?= e($athlete['sport_name']) ?></span></div>
<div><strong>Event</strong><span><?= e($athlete['event_name']) ?></span></div>
<div><strong>School</strong><span><?= e($athlete['school_name'] ?? '—') ?></span></div>
<div><strong>Status</strong><span><?= e(ucfirst($athlete['status'])) ?></span></div>
</div>

<h3>Assessment History</h3>
<?php if (!$assessments): ?>
<p class="empty">No assessments found for the selected period.</p>
<?php else: ?>
<?php foreach ($assessments as $assessment): ?>
<div class="report-assessment">
<div class="report-assessment-heading"><strong><?= e($assessment['date']) ?> · <?= e($assessment['type']) ?></strong></div>
<?php if (!empty($assessment['results'])): ?>
<table><thead><tr><th>Metric</th><th>Result</th><th>Notes</th></tr></thead><tbody>
<?php foreach ($assessment['results'] as $result): ?>
<tr><td><?= e($result['metric']) ?></td><td><?= e($result['value'] . ($result['unit'] ? ' ' . $result['unit'] : '')) ?></td><td><?= e($result['notes'] ?? '—') ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><p class="small">No metric results recorded.</p><?php endif; ?>
<?php if ($assessment['remarks']): ?><p class="small"><strong>Remarks:</strong> <?= e($assessment['remarks']) ?></p><?php endif; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
<?php elseif ($athleteId): ?>
<div class="alert danger">That athlete is not assigned to your coach profile.</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
