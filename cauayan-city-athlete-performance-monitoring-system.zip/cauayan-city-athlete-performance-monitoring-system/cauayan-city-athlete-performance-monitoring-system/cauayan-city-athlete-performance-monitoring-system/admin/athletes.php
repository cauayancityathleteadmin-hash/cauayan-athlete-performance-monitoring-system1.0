<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../includes/functions.php';
require_coach_or_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $pdo = db();

    if (!is_admin() && $action !== 'create') {
        http_response_code(403);
        exit('Coaches can only add athletes assigned to themselves.');
    }

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['athlete_id'] ?? 0);
        $first = trim($_POST['first_name'] ?? '');
        $middle = trim($_POST['middle_name'] ?? '');
        $last = trim($_POST['last_name'] ?? '');
        $suffix = trim($_POST['suffix'] ?? '');
        $birthdate = $_POST['birthdate'] ?? '';
        $gender = $_POST['gender'] ?? '';
        $contact = trim($_POST['contact_number'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $schoolName = trim($_POST['school_name'] ?? '');
        $sportName = trim($_POST['sport_name'] ?? '');
        $eventName = trim($_POST['event_name'] ?? '');
        $coachName = trim($_POST['coach_name'] ?? '');
        $coachId = 0;

        if (is_coach()) {
            $coachId = get_coach_id_for_user((int)current_user_id()) ?? 0;
        }

        $validEmail = $email === '' || filter_var($email, FILTER_VALIDATE_EMAIL);
        $birthObject = $birthdate === '' ? false : DateTime::createFromFormat('!Y-m-d', $birthdate);
        $birthValid = $birthObject !== false
            && $birthObject->format('Y-m-d') === $birthdate
            && $birthdate <= date('Y-m-d');
        $validationErrors = [];
        if ($first === '') $validationErrors[] = 'first name';
        if ($last === '') $validationErrors[] = 'last name';
        if (!$birthValid) $validationErrors[] = 'birthdate';
        if (!in_array($gender, ['male','female','other','prefer_not_to_say'], true)) $validationErrors[] = 'gender';
        if ($sportName === '') $validationErrors[] = 'sport';
        if ($eventName === '') $validationErrors[] = 'event';
        if (!$coachId && $coachName === '') $validationErrors[] = 'assigned coach';
        if (!$validEmail) $validationErrors[] = 'email';
        if ($validationErrors) {
            flash('danger', 'Please check: ' . implode(', ', $validationErrors) . '. School and suffix are optional.');
            redirect(is_coach() ? 'admin/athletes.php?add=1' : ($action === 'update' ? 'admin/athletes.php?edit=' . $id : 'admin/athletes.php'));
        }

        try {
            $pdo->beginTransaction();

            $schoolId = null;
            if ($schoolName !== '') {
                $stmt = $pdo->prepare('SELECT id FROM schools WHERE LOWER(school_name) = LOWER(?) LIMIT 1');
                $stmt->execute([$schoolName]);
                $schoolId = (int)($stmt->fetchColumn() ?: 0);
                if (!$schoolId) {
                    $stmt = $pdo->prepare('INSERT INTO schools (school_name) VALUES (?)');
                    $stmt->execute([$schoolName]);
                    $schoolId = (int)$pdo->lastInsertId();
                }
            }

            $stmt = $pdo->prepare('SELECT id FROM sports WHERE LOWER(sport_name) = LOWER(?) LIMIT 1');
            $stmt->execute([$sportName]);
            $sportId = (int)($stmt->fetchColumn() ?: 0);
            if (!$sportId) {
                $stmt = $pdo->prepare('INSERT INTO sports (sport_name) VALUES (?)');
                $stmt->execute([$sportName]);
                $sportId = (int)$pdo->lastInsertId();
            }

            $stmt = $pdo->prepare('SELECT id FROM events WHERE sport_id = ? AND LOWER(event_name) = LOWER(?) LIMIT 1');
            $stmt->execute([$sportId, $eventName]);
            $eventId = (int)($stmt->fetchColumn() ?: 0);
            if (!$eventId) {
                $stmt = $pdo->prepare('INSERT INTO events (sport_id, event_name) VALUES (?, ?)');
                $stmt->execute([$sportId, $eventName]);
                $eventId = (int)$pdo->lastInsertId();
            }

                        if (is_admin()) {
                                $stmt = $pdo->prepare(
                                        "SELECT c.id
                                         FROM coaches c
                                         JOIN users u ON u.id = c.user_id
                                         WHERE c.status = 'active' AND u.status = 'active'
                                             AND (c.coach_code = ? OR u.email = ?
                                                        OR LOWER(CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name, c.suffix)) = LOWER(?))
                                         LIMIT 1"
                                );
                                $stmt->execute([$coachName, $coachName, $coachName]);
                                $coachId = (int)($stmt->fetchColumn() ?: 0);
                        }
            if (!$coachId) {
                throw new RuntimeException('Assigned coach not found. Enter the coach ID, email, or exact full name of an active coach.');
            }

            if ($action === 'create') {
                $stmt = $pdo->prepare(
                    'INSERT INTO athletes
                    (athlete_code, first_name, middle_name, last_name, suffix, birthdate, gender, contact_number, email, address, school_id, sport_id, event_id, coach_id, status, date_registered)
                    VALUES ("TEMP", ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active", CURDATE())'
                );
                $stmt->execute([$first, $middle ?: null, $last, $suffix ?: null, $birthdate, $gender, $contact ?: null, $email ?: null, $address ?: null, $schoolId, $sportId, $eventId, $coachId]);
                $athleteId = (int)$pdo->lastInsertId();
                $athleteCode = generate_code('ATH', $athleteId);
                $pdo->prepare('UPDATE athletes SET athlete_code = ? WHERE id = ?')->execute([$athleteCode, $athleteId]);
                $pdo->prepare('INSERT INTO athlete_coach_history (athlete_id, coach_id, assigned_by, reason) VALUES (?, ?, ?, ?)')->execute([$athleteId, $coachId, current_user_id(), 'Initial coach assignment']);
                $pdo->prepare('INSERT INTO athlete_status_history (athlete_id, old_status, new_status, changed_by, reason) VALUES (?, NULL, "active", ?, ?)')->execute([$athleteId, current_user_id(), 'Initial registration']);
                $pdo->commit();
                audit('CREATE_ATHLETE', 'athlete', $athleteId, "Created athlete {$athleteCode}.");
                flash('success', "Athlete created. Athlete ID: {$athleteCode}");
            } else {
                $old = $pdo->prepare('SELECT coach_id, athlete_code FROM athletes WHERE id = ? FOR UPDATE');
                $old->execute([$id]);
                $existing = $old->fetch();
                if (!$existing) throw new RuntimeException('Athlete not found.');

                $pdo->prepare('UPDATE athletes SET first_name=?, middle_name=?, last_name=?, suffix=?, birthdate=?, gender=?, contact_number=?, email=?, address=?, school_id=?, sport_id=?, event_id=?, coach_id=? WHERE id=?')
                    ->execute([$first, $middle ?: null, $last, $suffix ?: null, $birthdate, $gender, $contact ?: null, $email ?: null, $address ?: null, $schoolId, $sportId, $eventId, $coachId, $id]);

                if ((int)$existing['coach_id'] !== $coachId) {
                    $pdo->prepare('UPDATE athlete_coach_history SET ended_at = NOW() WHERE athlete_id = ? AND ended_at IS NULL')->execute([$id]);
                    $pdo->prepare('INSERT INTO athlete_coach_history (athlete_id, coach_id, assigned_by, reason) VALUES (?, ?, ?, ?)')->execute([$id, $coachId, current_user_id(), 'Coach reassigned by Admin']);
                }
                $pdo->commit();
                audit('UPDATE_ATHLETE', 'athlete', $id, "Updated athlete {$existing['athlete_code']}.");
                if ((int)$existing['coach_id'] !== $coachId) audit('REASSIGN_ATHLETE', 'athlete', $id, "Reassigned {$existing['athlete_code']} to coach ID {$coachId}.");
                flash('success', 'Athlete information updated.');
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', $e instanceof RuntimeException ? $e->getMessage() : 'Could not save the athlete. Please check the entered values.');
        }
        redirect('admin/athletes.php');
    }

    if ($action === 'toggle_status') {
        $athleteId = (int)($_POST['athlete_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT status, athlete_code FROM athletes WHERE id = ?');
        $stmt->execute([$athleteId]);
        $athlete = $stmt->fetch();
        if ($athlete) {
            $newStatus = $athlete['status'] === 'active' ? 'inactive' : 'active';
            $pdo->prepare('UPDATE athletes SET status = ? WHERE id = ?')->execute([$newStatus, $athleteId]);
            $pdo->prepare('INSERT INTO athlete_status_history (athlete_id, old_status, new_status, changed_by, reason) VALUES (?, ?, ?, ?, ?)')->execute([$athleteId, $athlete['status'], $newStatus, current_user_id(), 'Status changed by Admin']);
            audit('UPDATE_ATHLETE_STATUS', 'athlete', $athleteId, "Athlete {$athlete['athlete_code']} changed to {$newStatus}.");
            flash('success', 'Athlete status updated.');
        }
        redirect('admin/athletes.php');
    }
}

$editId = (int)($_GET['edit'] ?? 0);
$editAthlete = null;
if ($editId) {
    $stmt = db()->prepare(
        "SELECT a.*, s.school_name, sp.sport_name, e.event_name,
                c.coach_code,
                CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name, c.suffix) AS coach_name
         FROM athletes a
         LEFT JOIN schools s ON s.id = a.school_id
         JOIN sports sp ON sp.id = a.sport_id
         JOIN events e ON e.id = a.event_id
         JOIN coaches c ON c.id = a.coach_id
         WHERE a.id = ?"
    );
    $stmt->execute([$editId]);
    $editAthlete = $stmt->fetch() ?: null;
}

$q = trim($_GET['q'] ?? '');
$params = [];
$sql = "SELECT a.*, s.school_name, sp.sport_name, e.event_name, c.coach_code,
        CONCAT_WS(' ', a.first_name, a.middle_name, a.last_name, a.suffix) AS athlete_name
        FROM athletes a
        LEFT JOIN schools s ON s.id=a.school_id
        JOIN sports sp ON sp.id=a.sport_id
        JOIN events e ON e.id=a.event_id
        JOIN coaches c ON c.id=a.coach_id";
if ($q !== '') {
    $sql .= " WHERE a.athlete_code LIKE ? OR a.first_name LIKE ? OR a.last_name LIKE ? OR c.coach_code LIKE ?";
    $like = "%{$q}%";
    $params = [$like, $like, $like, $like];
}
$sql .= " ORDER BY a.last_name, a.first_name";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$athletes = $stmt->fetchAll();

$pageTitle = is_admin() ? 'Manage Athletes' : 'Add Athlete';
require __DIR__ . '/../includes/header.php';
?>
<?php $showAthleteForm = isset($_GET['add']) || $editAthlete; ?>
<div class="page-title"><h1><?= e($pageTitle) ?></h1><div class="actions"><?php if (!$showAthleteForm): ?><a class="btn" href="<?= BASE_URL ?>/<?= is_admin() ? 'admin/athletes.php' : 'admin/athletes.php' ?>?add=1">Add Athlete</a><?php endif; ?></div></div>

<?php if ($showAthleteForm): ?>
<div class="panel">
<h2><?= $editAthlete ? 'Edit Athlete — ' . e($editAthlete['athlete_code']) : 'Register Athlete' ?></h2>
<form method="post">
<?= csrf_field() ?><input type="hidden" name="action" value="<?= $editAthlete ? 'update' : 'create' ?>">
<?php if ($editAthlete): ?><input type="hidden" name="athlete_id" value="<?= (int)$editAthlete['id'] ?>"><?php endif; ?>
<div class="form-grid">
<div class="form-group"><label>First Name *</label><input name="first_name" value="<?= e($editAthlete['first_name'] ?? '') ?>" required></div>
<div class="form-group"><label>Middle Name</label><input name="middle_name" value="<?= e($editAthlete['middle_name'] ?? '') ?>"></div>
<div class="form-group"><label>Last Name *</label><input name="last_name" value="<?= e($editAthlete['last_name'] ?? '') ?>" required></div>
<div class="form-group"><label>Suffix (optional)</label><input name="suffix" value="<?= e($editAthlete['suffix'] ?? '') ?>" placeholder="Jr., III (optional)"></div>
<div class="form-group"><label>Birthdate *</label><input type="date" name="birthdate" max="<?= date('Y-m-d') ?>" value="<?= e($editAthlete['birthdate'] ?? '') ?>" required></div>
<div class="form-group"><label>Gender *</label><select name="gender" required><option value="">Select</option><?php foreach(['male'=>'Male','female'=>'Female','other'=>'Other','prefer_not_to_say'=>'Prefer not to say'] as $value=>$label): ?><option value="<?= $value ?>" <?= (($editAthlete['gender'] ?? '') === $value) ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Contact Number</label><input name="contact_number" value="<?= e($editAthlete['contact_number'] ?? '') ?>"></div>
<div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($editAthlete['email'] ?? '') ?>"></div>
<div class="form-group full"><label>Address</label><textarea name="address"><?= e($editAthlete['address'] ?? '') ?></textarea></div>
<div class="form-group"><label>School</label><input name="school_name" value="<?= e($editAthlete['school_name'] ?? '') ?>" placeholder="Type school name"></div>
<div class="form-group"><label>Sport *</label><input name="sport_name" value="<?= e($editAthlete['sport_name'] ?? '') ?>" placeholder="Type sport name" required></div>
<div class="form-group"><label>Event *</label><input name="event_name" value="<?= e($editAthlete['event_name'] ?? '') ?>" placeholder="Type event name" required></div>
<?php if (is_admin()): ?><div class="form-group"><label>Assigned Coach *</label><input name="coach_name" value="<?= e($editAthlete['coach_code'] ?? '') ?>" placeholder="Coach ID, email, or exact full name" required></div><?php else: ?><div class="form-group"><label>Assigned Coach</label><input value="Your coach account" disabled><span class="small">This athlete will be assigned to you.</span></div><?php endif; ?>
</div>
<br><div class="actions"><button class="btn" type="submit"><?= $editAthlete ? 'Save Changes' : 'Register Athlete' ?></button><?php if($editAthlete): ?><a class="btn secondary" href="<?= BASE_URL ?>/admin/athletes.php">Cancel</a><?php endif; ?></div>
</form>
</div>
<?php endif; ?>

<?php if (is_admin()): ?>
<div class="panel">
<h2>Athletes</h2>
<form class="search-bar" method="get"><input name="q" value="<?= e($q) ?>" placeholder="Search ID, name, or coach ID"><button class="btn" type="submit">Search</button><a class="btn secondary" href="<?= BASE_URL ?>/admin/athletes.php">Clear</a></form>
<div class="table-wrap"><table>
<thead><tr><th>ID</th><th>Athlete</th><th>Sport / Event</th><th>School</th><th>Coach</th><th>Status</th><th>Action</th></tr></thead>
<tbody>
<?php foreach($athletes as $a): ?><tr>
<td><a href="<?= BASE_URL ?>/athletes/view.php?id=<?= (int)$a['id'] ?>"><?= e($a['athlete_code']) ?></a></td>
<td><?= e($a['athlete_name']) ?><br><span class="small">Age <?= calculate_age($a['birthdate']) ?></span></td>
<td><?= e($a['sport_name']) ?><br><span class="small"><?= e($a['event_name']) ?></span></td>
<td><?= e($a['school_name'] ?? '—') ?></td><td><?= e($a['coach_code']) ?></td>
<td><span class="badge <?= e($a['status']) ?>"><?= e(ucfirst($a['status'])) ?></span></td>
<td><div class="actions"><a class="btn secondary" href="<?= BASE_URL ?>/admin/athletes.php?edit=<?= (int)$a['id'] ?>">Edit</a><form method="post" data-confirm="Change this athlete's status?"><?= csrf_field() ?><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="athlete_id" value="<?= (int)$a['id'] ?>"><button class="btn secondary" type="submit"><?= $a['status']==='active'?'Mark Inactive':'Mark Active' ?></button></form></div></td>
</tr><?php endforeach; ?>
<?php if(!$athletes): ?><tr><td colspan="7" class="empty">No athletes found.</td></tr><?php endif; ?>
</tbody></table></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
