<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $first = trim($_POST['first_name'] ?? '');
        $middle = trim($_POST['middle_name'] ?? '');
        $last = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($first === '' || $last === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
            flash('danger', 'Complete the required fields. Password must be at least 10 characters.');
            redirect('admin/coaches.php');
        }

        $pdo = db();
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                'INSERT INTO users (email, password_hash, role, status) VALUES (?, ?, "coach", "active")'
            );
            $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
            $userId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare(
                'INSERT INTO coaches
                 (user_id, coach_code, first_name, middle_name, last_name, email, status, date_registered)
                 VALUES (?, ?, ?, ?, ?, ?, "active", CURDATE())'
            );
            $stmt->execute([$userId, 'TEMP', $first, $middle ?: null, $last, $email]);
            $coachId = (int)$pdo->lastInsertId();
            $coachCode = generate_code('COA', $coachId);

            $pdo->prepare('UPDATE coaches SET coach_code = ? WHERE id = ?')->execute([$coachCode, $coachId]);

            $pdo->commit();
            audit('CREATE_COACH', 'coach', $coachId, "Created coach {$coachCode}.");
            $coachName = trim($first . ' ' . $middle . ' ' . $last);
            $mailResult = send_coach_credentials($email, $coachName, $coachCode, $password);
            if ($mailResult === true) {
                flash('success', "Coach created. Login details were queued for delivery to {$email}. Check Gmail spam or promotions if they do not arrive. Coach ID: {$coachCode}");
            } elseif ($mailResult === null) {
                flash('warning', "Coach created, but email delivery is not configured. Set Gmail credentials and MAIL_FROM first. Coach ID: {$coachCode}; login email: {$email}");
            } else {
                flash('warning', "Coach created, but Gmail rejected the SMTP login. Generate a new Gmail App Password and update sendmail.ini. Coach ID: {$coachCode}; login email: {$email}");
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('danger', 'Could not create coach. The email may already be in use.');
        }

        redirect('admin/coaches.php');
    }

    if ($action === 'toggle_status') {
        $coachId = (int)($_POST['coach_id'] ?? 0);
        $stmt = db()->prepare('SELECT status, coach_code, user_id FROM coaches WHERE id = ?');
        $stmt->execute([$coachId]);
        $coach = $stmt->fetch();

        if ($coach) {
            $newStatus = $coach['status'] === 'active' ? 'inactive' : 'active';
            db()->prepare('UPDATE coaches SET status = ? WHERE id = ?')->execute([$newStatus, $coachId]);
            db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$newStatus, $coach['user_id']]);
            audit('UPDATE_COACH_STATUS', 'coach', $coachId, "Coach {$coach['coach_code']} changed to {$newStatus}.");
            flash('success', 'Coach status updated.');
        }
        redirect('admin/coaches.php');
    }

    if ($action === 'approve' || $action === 'reject') {
        $coachId = (int)($_POST['coach_id'] ?? 0);
        $reason = trim($_POST['reason'] ?? '');
        $stmt = db()->prepare(
            "SELECT c.id, c.user_id, c.coach_code, c.email,
                    CONCAT_WS(' ', c.first_name, c.middle_name, c.last_name, c.suffix) AS coach_name
             FROM coaches c JOIN users u ON u.id = c.user_id
             WHERE c.id = ? AND u.status = 'pending'"
        );
        $stmt->execute([$coachId]);
        $pending = $stmt->fetch();
        if (!$pending) {
            flash('danger', 'Pending coach application not found.');
            redirect('admin/coaches.php');
        }

        $newStatus = $action === 'approve' ? 'active' : 'rejected';
        db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$newStatus, $pending['user_id']]);
        db()->prepare('UPDATE coaches SET status = ? WHERE id = ?')->execute([$action === 'approve' ? 'active' : 'inactive', $coachId]);
        audit(strtoupper('COACH_' . $action), 'coach', $coachId, $reason ?: "Coach {$pending['coach_code']} {$action}ed.");

        $mailResult = send_coach_status_email($pending['email'], $pending['coach_name'], $pending['coach_code'], $newStatus, $reason ?: null);
        $mailMessage = $mailResult === true ? ' Notification queued.' : ($mailResult === null ? ' Email is not configured.' : ' Gmail rejected the notification.');
        flash($action === 'approve' ? 'success' : 'warning', 'Coach application ' . ($action === 'approve' ? 'approved.' : 'rejected.') . $mailMessage);
        redirect('admin/coaches.php');
    }
}

$coaches = db()->query(
    "SELECT c.*, u.email AS login_email,
            (SELECT COUNT(*) FROM athletes a WHERE a.coach_id = c.id AND a.status='active') AS athlete_count
     FROM coaches c
     JOIN users u ON u.id = c.user_id
     ORDER BY c.last_name, c.first_name"
)->fetchAll();

$pendingCoaches = db()->query(
    "SELECT c.id, c.coach_code, c.email, c.first_name, c.middle_name, c.last_name, c.date_registered
     FROM coaches c JOIN users u ON u.id = c.user_id
     WHERE u.status = 'pending'
     ORDER BY c.created_at DESC"
)->fetchAll();

$pageTitle = 'Manage Coaches';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-title">
<h1>Manage Coaches</h1><div class="actions"><a class="btn" href="<?= BASE_URL ?>/admin/coaches.php?add=1">Add Coach</a></div>
</div>

<div class="panel">
<h2>Pending Coach Applications</h2>
<?php if (!$pendingCoaches): ?><p class="empty">No pending applications.</p><?php else: ?>
<table><thead><tr><th>Name</th><th>Email</th><th>Submitted</th><th>Action</th></tr></thead><tbody>
<?php foreach ($pendingCoaches as $pending): ?>
<tr><td><?= e(trim($pending['first_name'] . ' ' . $pending['middle_name'] . ' ' . $pending['last_name'])) ?></td><td><?= e($pending['email']) ?></td><td><?= e($pending['date_registered']) ?></td><td><div class="actions"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="coach_id" value="<?= (int)$pending['id'] ?>"><button class="btn" type="submit">Approve</button></form><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reject"><input type="hidden" name="coach_id" value="<?= (int)$pending['id'] ?>"><input type="text" name="reason" placeholder="Optional reason"><button class="btn secondary" type="submit">Reject</button></form></div></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php endif; ?>
</div>

<?php if (isset($_GET['add'])): ?>
<div class="panel">
<h2>Create Coach</h2>
<form method="post">
<?= csrf_field() ?><input type="hidden" name="action" value="create">
<div class="form-grid">
<div class="form-group"><label>First Name *</label><input name="first_name" required></div>
<div class="form-group"><label>Middle Name</label><input name="middle_name"></div>
<div class="form-group"><label>Last Name *</label><input name="last_name" required></div>
<div class="form-group"><label>Login Email *</label><input type="email" name="email" required></div>
<div class="form-group"><label>Initial Password *</label><input type="password" name="password" minlength="10" required></div>
</div>
<br><button class="btn" type="submit">Create Coach</button>
</form>
</div>
<?php endif; ?>

<div class="panel">
<h2>Coaches</h2>
<table>
<thead><tr><th>Coach ID</th><th>Name</th><th>Email</th><th>Active Athletes</th><th>Status</th><th>Action</th></tr></thead>
<tbody>
<?php foreach ($coaches as $coach): ?>
<tr>
<td><?= e($coach['coach_code']) ?></td>
<td><?= e(trim($coach['first_name'].' '.$coach['middle_name'].' '.$coach['last_name'])) ?></td>
<td><?= e($coach['login_email']) ?></td>
<td><?= (int)$coach['athlete_count'] ?></td>
<td><span class="badge <?= e($coach['status']) ?>"><?= e(ucfirst($coach['status'])) ?></span></td>
<td>
<form method="post" class="actions">
<?= csrf_field() ?><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="coach_id" value="<?= (int)$coach['id'] ?>">
<button class="btn secondary" type="submit"><?= $coach['status'] === 'active' ? 'Deactivate' : 'Activate' ?></button>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
