<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Invalid security token. Please go back and try again.');
    }
}

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function current_user_id(): ?int
{
    return isset($_SESSION['user']['id']) ? (int) $_SESSION['user']['id'] : null;
}

function is_admin(): bool
{
    return ($_SESSION['user']['role'] ?? '') === 'admin';
}

function is_coach(): bool
{
    return ($_SESSION['user']['role'] ?? '') === 'coach';
}

function generate_code(string $prefix, int $id): string
{
    return $prefix . '-' . str_pad((string)$id, 6, '0', STR_PAD_LEFT);
}

function calculate_age(string $birthdate): int
{
    $birth = new DateTime($birthdate);
    $today = new DateTime('today');
    return $birth->diff($today)->y;
}

function audit(
    string $action,
    ?string $entityType = null,
    ?int $entityId = null,
    ?string $description = null
): void {
    $stmt = db()->prepare(
        'INSERT INTO audit_logs
         (user_id, action, entity_type, entity_id, description, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );

    $stmt->execute([
        current_user_id(),
        $action,
        $entityType,
        $entityId,
        $description,
        $_SERVER['REMOTE_ADDR'] ?? null,
        substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
    ]);
}

function mail_transport_ready(): bool
{
    $sendmailPath = (string)ini_get('sendmail_path');
    $sendmailConfig = 'C:\\xampp\\sendmail\\sendmail.ini';
    $sendmailContents = is_file($sendmailConfig) ? file_get_contents($sendmailConfig) : false;
    $hasSmtpPassword = is_string($sendmailContents)
           && preg_match('/^auth_password[ \t]*=[ \t]*([^\r\n]+)\r?$/m', $sendmailContents) === 1;
    return $sendmailPath !== '' && is_file('C:\\xampp\\sendmail\\sendmail.exe')
        && MAIL_FROM !== 'noreply@localhost' && $hasSmtpPassword;
}

function send_coach_credentials(string $email, string $coachName, string $coachCode, string $password): ?bool
{
    if (!mail_transport_ready()) {
        return null;
    }

    $subject = APP_NAME . ' coach account';
    $message = "Hello {$coachName},\n\n"
        . "Your coach account has been created.\n\n"
        . "Login email: {$email}\n"
        . "Coach ID: {$coachCode}\n"
        . "Temporary password: {$password}\n\n"
        . "Please change this password after your first login.\n\n"
        . APP_NAME;
    $headers = [
        'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>',
        'Content-Type: text/plain; charset=UTF-8',
    ];

    return mail($email, $subject, $message, implode("\r\n", $headers));
}

function send_coach_status_email(string $email, string $coachName, string $coachCode, string $status, ?string $reason = null): ?bool
{
    if (!mail_transport_ready()) {
        return null;
    }

    $approved = $status === 'active';
    $subject = APP_NAME . ($approved ? ' registration approved' : ' registration rejected');
    $message = "Hello {$coachName},\n\n";
    if ($approved) {
        $message .= "Your coach registration has been approved.\n\n"
            . "Coach ID: {$coachCode}\n"
            . "Login email: {$email}\n\n"
            . "You can now log in using the password you created during registration.\n";
    } else {
        $message .= "Your coach registration was not approved at this time.\n\n";
        if ($reason) {
            $message .= "Reason: {$reason}\n\n";
        }
        $message .= "Please contact the administrator if you need more information.\n";
    }
    $message .= "\n" . APP_NAME;
    $headers = [
        'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>',
        'Content-Type: text/plain; charset=UTF-8',
    ];

    return mail($email, $subject, $message, implode("\r\n", $headers));
}

function get_coach_id_for_user(int $userId): ?int
{
    $stmt = db()->prepare('SELECT id FROM coaches WHERE user_id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $id = $stmt->fetchColumn();

    return $id === false ? null : (int)$id;
}

function coach_can_manage_athlete(int $athleteId, int $userId): bool
{
    if (is_admin()) {
        return true;
    }

    $coachId = get_coach_id_for_user($userId);
    if (!$coachId) {
        return false;
    }

    $stmt = db()->prepare('SELECT COUNT(*) FROM athletes WHERE id = ? AND coach_id = ?');
    $stmt->execute([$athleteId, $coachId]);

    return (int)$stmt->fetchColumn() === 1;
}

function require_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Method Not Allowed');
    }
}
