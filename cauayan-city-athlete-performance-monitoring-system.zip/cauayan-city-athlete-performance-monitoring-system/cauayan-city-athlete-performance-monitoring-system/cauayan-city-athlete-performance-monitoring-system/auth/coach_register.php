<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';

if (current_user()) {
    redirect('index.php');
}

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $first = trim($_POST['first_name'] ?? '');
    $middle = trim($_POST['middle_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($first === '' || $last === '') {
        $error = 'First name and last name are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif (strlen($password) < 10) {
        $error = 'Password must be at least 10 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $pdo = db();
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('INSERT INTO users (email, password_hash, role, status) VALUES (?, ?, "coach", "pending")');
            $stmt->execute([$email, password_hash($password, PASSWORD_DEFAULT)]);
            $userId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare(
                'INSERT INTO coaches
                 (user_id, coach_code, first_name, middle_name, last_name, email, status, date_registered)
                 VALUES (?, ?, ?, ?, ?, ?, "inactive", CURDATE())'
            );
            $stmt->execute([$userId, 'TEMP', $first, $middle ?: null, $last, $email]);
            $coachId = (int)$pdo->lastInsertId();
            $coachCode = generate_code('COA', $coachId);
            $pdo->prepare('UPDATE coaches SET coach_code = ? WHERE id = ?')->execute([$coachCode, $coachId]);
            $pdo->commit();

            audit('COACH_REGISTRATION', 'coach', $coachId, "Coach registration submitted: {$coachCode}.");
            flash('success', 'Registration submitted. An administrator must approve your account before you can log in.');
            redirect('auth/login.php');
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Registration could not be completed. That email may already be registered.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Coach Registration | <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="login-page">
<div class="login-box">
<h1>Coach Registration</h1>
<p class="small">Submit your details for administrator approval.</p>
<?php if ($error): ?><div class="alert danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<?= csrf_field() ?>
<div class="form-group"><label>First Name *</label><input name="first_name" value="<?= e($_POST['first_name'] ?? '') ?>" required></div>
<div class="form-group"><label>Middle Name</label><input name="middle_name" value="<?= e($_POST['middle_name'] ?? '') ?>"></div>
<div class="form-group"><label>Last Name *</label><input name="last_name" value="<?= e($_POST['last_name'] ?? '') ?>" required></div>
<div class="form-group"><label>Email *</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
<div class="form-group"><label>Password *</label><input type="password" name="password" minlength="10" required></div>
<div class="form-group"><label>Confirm Password *</label><input type="password" name="confirm_password" minlength="10" required></div>
<button class="btn" type="submit">Submit Registration</button>
</form>
<p class="small login-register"><a href="<?= BASE_URL ?>/auth/login.php">Back to login</a></p>
</div>
</body>
</html>
